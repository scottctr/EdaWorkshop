﻿namespace ThreeAmigosHealthServer.Pages
{
    public enum MedicalDiscipline
    {
        Fertiliy,
        PostAcuteCare,
        Sleep,
    }
}
