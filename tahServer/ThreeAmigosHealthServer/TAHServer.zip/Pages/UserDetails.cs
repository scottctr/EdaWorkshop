﻿namespace ThreeAmigosHealthServer.Pages
{
    public record UserDetails(string UserName, MedicalDiscipline Discipline);
}
